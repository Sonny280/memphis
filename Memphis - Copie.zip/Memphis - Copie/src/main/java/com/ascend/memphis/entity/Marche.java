package com.ascend.memphis.entity;

import com.ascend.memphis.screen.Entreprise;
import io.jmix.core.DeletePolicy;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.OnDeleteInverse;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.UUID;

@JmixEntity
@Table(name = "MARCHE", indexes = {
        @Index(name = "IDX_MARCHE_PROJET", columnList = "PROJET_ID"),
        @Index(name = "IDX_MARCHE_TYPEMARCHE", columnList = "TYPEMARCHE_ID"),
        @Index(name = "IDX_MARCHE_ENTREPRISE", columnList = "ENTREPRISE_ID"),
        @Index(name = "IDX_MARCHE_CONTROLLEUR", columnList = "CONTROLLEUR_ID"),
        @Index(name = "IDX_MARCHE_LOTPROJET", columnList = "LOTPROJET_ID")
})
@Entity
public class Marche {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "NUM_MARCHE", nullable = false)
    @NotNull
    private String num_marche;

    @Column(name = "NUM_MARCHEADMIN", nullable = false)
    @NotNull
    private String num_marcheadmin;

    @Column(name = "OBJET", nullable = false)
    @NotNull
    private String objet;

    @OnDeleteInverse(DeletePolicy.DENY)
    @JoinColumn(name = "PROJET_ID", nullable = false)
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Projet projet;

    @Column(name = "MONTANT_TRAVAUX", nullable = false, precision = 19, scale = 0)
    @NotNull
    private BigDecimal montant_travaux;

    @OnDeleteInverse(DeletePolicy.DENY)
    @JoinColumn(name = "TYPEMARCHE_ID", nullable = false)
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private TypeMarche typemarche;

    @OnDeleteInverse(DeletePolicy.DENY)
    @JoinColumn(name = "ENTREPRISE_ID", nullable = false)
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Entreprise entreprise;

    @JoinColumn(name = "CONTROLLEUR_ID", nullable = false)
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Entreprise controlleur;

    @OnDeleteInverse(DeletePolicy.DENY)
    @JoinColumn(name = "LOTPROJET_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Projet lotprojet;

    @Column(name = "TAUX_TVA", nullable = false)
    @NotNull
    private Double taux_tva;

    @Column(name = "TAUX_MOE")
    private Double taux_moe;

    @Column(name = "TAUX_REMISE")
    private Double taux_remise;

    @Column(name = "MONTANT_MOE", precision = 19, scale = 0)
    private BigDecimal montant_moe;

    @Column(name = "MONTANT_TVA", nullable = false)
    @NotNull
    private String montant_tva;

    @Column(name = "MONTANT_REMISE", precision = 19, scale = 0)
    private BigDecimal montant_remise;

    @Column(name = "MONTANT_TTC", precision = 19, scale = 0)
    private BigDecimal montant_ttc;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    public Projet getLotprojet() {
        return lotprojet;
    }

    public void setLotprojet(Projet lotprojet) {
        this.lotprojet = lotprojet;
    }

    public Entreprise getControlleur() {
        return controlleur;
    }

    public void setControlleur(Entreprise controlleur) {
        this.controlleur = controlleur;
    }

    public Entreprise getEntreprise() {
        return entreprise;
    }

    public void setEntreprise(Entreprise entreprise) {
        this.entreprise = entreprise;
    }

    public TypeMarche getTypemarche() {
        return typemarche;
    }

    public void setTypemarche(TypeMarche typemarche) {
        this.typemarche = typemarche;
    }

    public BigDecimal getMontant_ttc() {
        return montant_ttc;
    }

    public void setMontant_ttc(BigDecimal montant_ttc) {
        this.montant_ttc = montant_ttc;
    }

    public BigDecimal getMontant_remise() {
        return montant_remise;
    }

    public void setMontant_remise(BigDecimal montant_remise) {
        this.montant_remise = montant_remise;
    }

    public String getMontant_tva() {
        return montant_tva;
    }

    public void setMontant_tva(String montant_tva) {
        this.montant_tva = montant_tva;
    }

    public BigDecimal getMontant_moe() {
        return montant_moe;
    }

    public void setMontant_moe(BigDecimal montant_moe) {
        this.montant_moe = montant_moe;
    }

    public Double getTaux_remise() {
        return taux_remise;
    }

    public void setTaux_remise(Double taux_remise) {
        this.taux_remise = taux_remise;
    }

    public Double getTaux_moe() {
        return taux_moe;
    }

    public void setTaux_moe(Double taux_moe) {
        this.taux_moe = taux_moe;
    }

    public Double getTaux_tva() {
        return taux_tva;
    }

    public void setTaux_tva(Double taux_tva) {
        this.taux_tva = taux_tva;
    }

    public BigDecimal getMontant_travaux() {
        return montant_travaux;
    }

    public void setMontant_travaux(BigDecimal montant_travaux) {
        this.montant_travaux = montant_travaux;
    }

    public Projet getProjet() {
        return projet;
    }

    public void setProjet(Projet projet) {
        this.projet = projet;
    }

    public String getObjet() {
        return objet;
    }

    public void setObjet(String objet) {
        this.objet = objet;
    }

    public String getNum_marcheadmin() {
        return num_marcheadmin;
    }

    public void setNum_marcheadmin(String num_marcheadmin) {
        this.num_marcheadmin = num_marcheadmin;
    }

    public String getNum_marche() {
        return num_marche;
    }

    public void setNum_marche(String num_marche) {
        this.num_marche = num_marche;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}