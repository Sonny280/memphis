package com.ascend.memphis.screen;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import java.util.UUID;

@JmixEntity
@Table(name = "BANQUE")
@Entity
public class Banque {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @NotNull(message = "Sigle Obligatoire")
    @Column(name = "NOM_COURT")
    private String nom_court;

    @NotNull(message = "Nom de l'entreprise obligatoire")
    @Column(name = "DESIGNATION")
    private String designation;

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getNom_court() {
        return nom_court;
    }

    public void setNom_court(String nom_court) {
        this.nom_court = nom_court;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}