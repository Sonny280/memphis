package com.ascend.memphis.screen.entreprise;

import io.jmix.ui.screen.*;
import com.ascend.memphis.screen.Entreprise;

@UiController("Entreprise.edit")
@UiDescriptor("entreprise-edit.xml")
@EditedEntityContainer("entrepriseDc")
public class EntrepriseEdit extends StandardEditor<Entreprise> {
}