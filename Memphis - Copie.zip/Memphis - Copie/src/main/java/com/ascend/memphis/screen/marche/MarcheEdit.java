package com.ascend.memphis.screen.marche;

import io.jmix.ui.screen.*;
import com.ascend.memphis.entity.Marche;

@UiController("Marche.edit")
@UiDescriptor("marche-edit.xml")
@EditedEntityContainer("marcheDc")
public class MarcheEdit extends StandardEditor<Marche> {
}