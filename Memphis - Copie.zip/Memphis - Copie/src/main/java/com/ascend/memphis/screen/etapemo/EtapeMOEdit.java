package com.ascend.memphis.screen.etapemo;

import io.jmix.ui.screen.*;
import com.ascend.memphis.entity.EtapeMO;

@UiController("EtapeMO.edit")
@UiDescriptor("etape-mo-edit.xml")
@EditedEntityContainer("etapeMODc")
public class EtapeMOEdit extends StandardEditor<EtapeMO> {
}