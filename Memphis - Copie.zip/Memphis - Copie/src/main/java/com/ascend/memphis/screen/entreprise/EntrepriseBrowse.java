package com.ascend.memphis.screen.entreprise;

import io.jmix.ui.screen.*;
import com.ascend.memphis.screen.Entreprise;

@UiController("Entreprise.browse")
@UiDescriptor("entreprise-browse.xml")
@LookupComponent("entreprisesTable")
public class EntrepriseBrowse extends StandardLookup<Entreprise> {
}