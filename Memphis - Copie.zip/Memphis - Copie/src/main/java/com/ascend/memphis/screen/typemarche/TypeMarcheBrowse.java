package com.ascend.memphis.screen.typemarche;

import io.jmix.ui.screen.*;
import com.ascend.memphis.entity.TypeMarche;

@UiController("TypeMarche.browse")
@UiDescriptor("type-marche-browse.xml")
@LookupComponent("typeMarchesTable")
public class TypeMarcheBrowse extends StandardLookup<TypeMarche> {
}