package com.ascend.memphis.screen.dirigeant;

import io.jmix.ui.screen.*;
import com.ascend.memphis.entity.Dirigeant;

@UiController("Dirigeant.browse")
@UiDescriptor("dirigeant-browse.xml")
@LookupComponent("dirigeantsTable")
public class DirigeantBrowse extends StandardLookup<Dirigeant> {
}