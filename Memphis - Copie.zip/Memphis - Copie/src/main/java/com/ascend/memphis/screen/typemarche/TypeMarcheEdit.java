package com.ascend.memphis.screen.typemarche;

import io.jmix.ui.screen.*;
import com.ascend.memphis.entity.TypeMarche;

@UiController("TypeMarche.edit")
@UiDescriptor("type-marche-edit.xml")
@EditedEntityContainer("typeMarcheDc")
public class TypeMarcheEdit extends StandardEditor<TypeMarche> {
}