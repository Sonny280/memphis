package com.ascend.memphis.screen.statutmarche;

import io.jmix.ui.screen.*;
import com.ascend.memphis.entity.StatutMarche;

@UiController("StatutMarche.edit")
@UiDescriptor("statut-marche-edit.xml")
@EditedEntityContainer("statutMarcheDc")
public class StatutMarcheEdit extends StandardEditor<StatutMarche> {
}