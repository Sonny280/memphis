package com.ascend.memphis.screen.nature;

import io.jmix.ui.screen.*;
import com.ascend.memphis.screen.Nature;

@UiController("Nature.browse")
@UiDescriptor("nature-browse.xml")
@LookupComponent("naturesTable")
public class NatureBrowse extends StandardLookup<Nature> {
}