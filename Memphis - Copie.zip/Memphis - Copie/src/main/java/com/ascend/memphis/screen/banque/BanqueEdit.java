package com.ascend.memphis.screen.banque;

import io.jmix.ui.screen.*;
import com.ascend.memphis.screen.Banque;

@UiController("Banque.edit")
@UiDescriptor("banque-edit.xml")
@EditedEntityContainer("banqueDc")
public class BanqueEdit extends StandardEditor<Banque> {
}