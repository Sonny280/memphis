package com.ascend.memphis.screen.tets;

import io.jmix.ui.screen.*;
import com.ascend.memphis.entity.Tets;

@UiController("Tets.edit")
@UiDescriptor("tets-edit.xml")
@EditedEntityContainer("tetsDc")
public class TetsEdit extends StandardEditor<Tets> {
}