package com.ascend.memphis.screen.marche;

import io.jmix.ui.screen.*;
import com.ascend.memphis.entity.Marche;

@UiController("Marche.browse")
@UiDescriptor("marche-browse.xml")
@LookupComponent("marchesTable")
public class MarcheBrowse extends StandardLookup<Marche> {
}