package com.ascend.memphis.screen;

import com.ascend.memphis.entity.Departement;
import com.ascend.memphis.entity.Dirigeant;
import com.ascend.memphis.entity.Pays;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.Composition;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.UUID;

@JmixEntity
@Table(name = "ENTREPRISE", indexes = {
        @Index(name = "IDX_ENTREPRISE_NATUREENTREPRIS", columnList = "NATURE_ENTREPRISE"),
        @Index(name = "IDX_ENTREPRISE_PAYS", columnList = "PAYS"),
        @Index(name = "IDX_ENTREPRISE_DEPARTEMENT", columnList = "DEPARTEMENT")
})
@Entity
public class Entreprise {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Composition
    @OneToMany(mappedBy = "entreprise")
    private List<Dirigeant> dirigeant;

    @Column(name = "RAISON_SOCIALE", nullable = false)
    @NotNull
    private String raison_sociale;

    @Column(name = "SIEGE", nullable = false)
    @NotNull
    private String siege;

    @JoinColumn(name = "NATURE_ENTREPRISE", nullable = false)
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Nature nature;

    @Column(name = "REPRESENTANT", nullable = false)
    @NotNull
    private String representant;

    @Column(name = "FONCTION")
    private String fonction;

    @Column(name = "ADRESSE", nullable = false)
    @NotNull
    private String adresse;

    @Column(name = "TELEPHONE", nullable = false)
    @NotNull
    private String telephone;

    @Column(name = "FAX", nullable = false)
    @NotNull
    private String fax;

    @Column(name = "DOMICIALISATION", nullable = false)
    @NotNull
    private String domicialisation;

    @JoinColumn(name = "PAYS", nullable = false)
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Pays name;

    @Column(name = "N_REGISTRE_DE_COMMERCE", nullable = false)
    @NotNull
    private String n_registre_de_commerce;

    @Column(name = "COMPTE_CONTRIBUABLE", nullable = false)
    @NotNull
    private String compte_contribuable;

    @Email
    @Column(name = "EMAIL", nullable = false)
    @NotNull
    private String email;

    @JoinColumn(name = "DEPARTEMENT", nullable = false)
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Departement departement;

    @Column(name = "VILLE", nullable = false)
    @NotNull
    private String ville;

    public List<Dirigeant> getDirigeant() {
        return dirigeant;
    }

    public void setDirigeant(List<Dirigeant> dirigeant) {
        this.dirigeant = dirigeant;
    }

    public String getVille() {
        return ville;
    }

    public void setVille(String ville) {
        this.ville = ville;
    }

    public Departement getDepartement() {
        return departement;
    }

    public void setDepartement(Departement departement) {
        this.departement = departement;
    }

    public Pays getName() {
        return name;
    }

    public void setName(Pays pays) {
        this.name = pays;
    }

    public String getDomicialisation() {
        return domicialisation;
    }

    public void setDomicialisation(String domicialisation) {
        this.domicialisation = domicialisation;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCompte_contribuable() {
        return compte_contribuable;
    }

    public void setCompte_contribuable(String compte_contribuable) {
        this.compte_contribuable = compte_contribuable;
    }

    public String getN_registre_de_commerce() {
        return n_registre_de_commerce;
    }

    public void setN_registre_de_commerce(String n_numero_de_commerce) {
        this.n_registre_de_commerce = n_numero_de_commerce;
    }

    public String getSiege() {
        return siege;
    }

    public void setSiege(String siege) {
        this.siege = siege;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public String getFonction() {
        return fonction;
    }

    public void setFonction(String fonction) {
        this.fonction = fonction;
    }

    public String getRepresentant() {
        return representant;
    }

    public void setRepresentant(String representant) {
        this.representant = representant;
    }

    public Nature getNature() {
        return nature;
    }

    public void setNature(Nature nature) {
        this.nature = nature;
    }

    public String getRaison_sociale() {
        return raison_sociale;
    }

    public void setRaison_sociale(String raison_sociale) {
        this.raison_sociale = raison_sociale;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}