package com.ascend.memphis.screen.dirigeant;

import io.jmix.ui.screen.*;
import com.ascend.memphis.entity.Dirigeant;

@UiController("Dirigeant.edit")
@UiDescriptor("dirigeant-edit.xml")
@EditedEntityContainer("dirigeantDc")
public class DirigeantEdit extends StandardEditor<Dirigeant> {
}