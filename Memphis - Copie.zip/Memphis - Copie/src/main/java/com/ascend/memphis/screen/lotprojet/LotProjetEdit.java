package com.ascend.memphis.screen.lotprojet;

import io.jmix.ui.action.Action;
import io.jmix.ui.screen.*;
import com.ascend.memphis.entity.LotProjet;

@UiController("LotProjet.edit")
@UiDescriptor("lot-projet-edit.xml")
@EditedEntityContainer("lotProjetDc")
public class LotProjetEdit extends StandardEditor<LotProjet> {
    @Subscribe("detailLotTable.importDQE")
    public void onDetailLotTableImportDQE(Action.ActionPerformedEvent event) {
        
    }
}