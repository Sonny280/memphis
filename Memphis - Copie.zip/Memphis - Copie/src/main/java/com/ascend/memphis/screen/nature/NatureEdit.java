package com.ascend.memphis.screen.nature;

import io.jmix.ui.screen.*;
import com.ascend.memphis.screen.Nature;

@UiController("Nature.edit")
@UiDescriptor("nature-edit.xml")
@EditedEntityContainer("natureDc")
public class NatureEdit extends StandardEditor<Nature> {
}