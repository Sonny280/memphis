package com.ascend.memphis.screen.tets;

import io.jmix.ui.screen.*;
import com.ascend.memphis.entity.Tets;

@UiController("Tets.browse")
@UiDescriptor("tets-browse.xml")
@LookupComponent("tetsesTable")
public class TetsBrowse extends StandardLookup<Tets> {
}