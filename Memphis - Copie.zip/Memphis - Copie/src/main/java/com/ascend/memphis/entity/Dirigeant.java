package com.ascend.memphis.entity;

import com.ascend.memphis.screen.Entreprise;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.UUID;

@JmixEntity
@Table(name = "DIRIGEANT", indexes = {
        @Index(name = "IDX_DIRIGEANT_ENTREPRISE", columnList = "ENTREPRISE")
})
@Entity
public class Dirigeant {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @JoinColumn(name = "ENTREPRISE")
    @ManyToOne(fetch = FetchType.LAZY)
    private Entreprise entreprise;

    @Column(name = "NOM_DIRIGEANT", nullable = false)
    @NotNull
    private String nom_dirigeant;

    @Column(name = "TELEPHONE", nullable = false)
    @NotNull
    private String telephone;

    @Column(name = "EMAIL", nullable = false)
    private String email;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getNom_dirigeant() {
        return nom_dirigeant;
    }

    public void setNom_dirigeant(String nom_dirigeant) {
        this.nom_dirigeant = nom_dirigeant;
    }

    public Entreprise getEntreprise() {
        return entreprise;
    }

    public void setEntreprise(Entreprise entreprise) {
        this.entreprise = entreprise;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}