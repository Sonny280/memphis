package com.ascend.memphis.screen.banque;

import io.jmix.ui.screen.*;
import com.ascend.memphis.screen.Banque;

@UiController("Banque.browse")
@UiDescriptor("banque-browse.xml")
@LookupComponent("banquesTable")
public class BanqueBrowse extends StandardLookup<Banque> {
}