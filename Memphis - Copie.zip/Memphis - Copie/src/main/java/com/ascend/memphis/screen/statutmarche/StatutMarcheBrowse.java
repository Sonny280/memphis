package com.ascend.memphis.screen.statutmarche;

import io.jmix.ui.screen.*;
import com.ascend.memphis.entity.StatutMarche;

@UiController("StatutMarche.browse")
@UiDescriptor("statut-marche-browse.xml")
@LookupComponent("statutMarchesTable")
public class StatutMarcheBrowse extends StandardLookup<StatutMarche> {
}