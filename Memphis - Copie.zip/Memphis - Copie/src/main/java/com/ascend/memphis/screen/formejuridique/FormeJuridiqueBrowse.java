package com.ascend.memphis.screen.formejuridique;

import io.jmix.ui.screen.*;
import com.ascend.memphis.screen.FormeJuridique;

@UiController("FormeJuridique.browse")
@UiDescriptor("forme-juridique-browse.xml")
@LookupComponent("formeJuridiquesTable")
public class FormeJuridiqueBrowse extends StandardLookup<FormeJuridique> {
}