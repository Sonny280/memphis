package com.ascend.memphis.screen.formejuridique;

import io.jmix.ui.screen.*;
import com.ascend.memphis.screen.FormeJuridique;

@UiController("FormeJuridique.edit")
@UiDescriptor("forme-juridique-edit.xml")
@EditedEntityContainer("formeJuridiqueDc")
public class FormeJuridiqueEdit extends StandardEditor<FormeJuridique> {
}